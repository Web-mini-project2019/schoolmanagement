<?php
$name=$_POST['id'];
$pwd=$_POST['pwd'];
$sql=mysqli_connect("localhost","root","","schoolmanagement");
if ($sql){
    $res=mysqli_query($sql,"select * from studentlogin where username='$name' and password='$pwd'");
    if (mysqli_num_rows($res)>0){
        exit('1');
    }
    else{
        exit('0');
    }
}