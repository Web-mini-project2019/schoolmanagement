<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>School Management Login </title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-3.4.1.js"></script>

</head>

<body>
<h2 align="center">Student record</h2>
<div class="container">
    <br><br><br><br>

    <div class="col-md-4 col-md-offset-4">

        <div class="panel panel-primary">

            <div class="panel-heading">
                <h3 class="panel-title">login In</h3>
            </div>
            <div class="panel-body">
                <form method="post">
                    <fieldset>
                        <div class="form-group">
                            <input class="form-control" placeholder="Login Id"  id="id" name="id" type="text" autofocus autocomplete="off" required>
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Password" id="password"name="password" type="password" value="" required>
                        </div>

                        <!-- Change this to a button or input when using this as a form -->
                        <button id="login" class="btn btn-lg btn-success btn-block">LOGIN</button>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
</div>

<!-- jQuery -->
<script type="text/javascript">
    $(document).ready(function () {
    $('#login').bind('click',function () {
        var id=$('#id').val();
        var pwd=$('#password').val();
        if (id=="" || pwd=="")
        alert("Please fill out the information");
        else {
            $.ajax({
                url: 'student_validate.php',
                method: "post",
                dataType: "text",
                data: {
                    'id': id,
                    'pwd': pwd,
                },
                success: function (response) {
                    if (response=='1')
                        window.location.href="view.php";
                    else
                        alert("Invalid user");
                }
            })
        }
    })
    })

</script>
</body>
</html>
